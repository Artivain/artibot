"use strict"
export const DOC_VERSIONS = [
	'stable',
	'v5.1',
	'v5.0',
];
