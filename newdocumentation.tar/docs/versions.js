"use strict"
export const DOC_VERSIONS = [
	'stable',
	'v5.0',
];
